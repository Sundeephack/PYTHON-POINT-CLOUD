# py-pointcloud-viewer

---

Point cloud sequence viewer with PyQT

If you want to run this code, please download & extract data. [Link](http://multispectral.kaist.ac.kr/smhwang/py-pointcloud-viewer/data.zip)


[![ScreenShot](demo_img.png)](https://youtu.be/MRCTbXgI_8c)